rrdpath = '/home/r/Desktop/9no/Redes3/AdministracionDeServiciosEnRED/2_Practica/TrendLineal/RRD/'
pngpath = '/home/r/Desktop/9no/Redes3/AdministracionDeServiciosEnRED/2_Practica/TrendLineal/IMG/'
rrdname= "trend.rrd"