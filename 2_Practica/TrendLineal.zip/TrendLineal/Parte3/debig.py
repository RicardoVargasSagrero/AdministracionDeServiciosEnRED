from Parte3.Notify2 import send_alert_attached

send_alert_attached("Error en sistema","Pruebas.pdf")