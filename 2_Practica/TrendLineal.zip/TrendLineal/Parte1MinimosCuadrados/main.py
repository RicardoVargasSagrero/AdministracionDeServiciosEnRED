from Parte1MinimosCuadrados.getSNMP import consultaSNMP
import time
import rrdtool
from path import *
import threading
from Parte3.Notify import send_alert_attached
from Parte1MinimosCuadrados.pdfCreator import crearPDF

CPU_UMBRAL = [70, 80, 90]
RAM_UMBRAL = 70
DISC_UMBRAL = 80

# Extramos informacion del TXT
def extraerAgentesTxt(comunidadAgentes,ipAgentes):
    totalAgentes = 0
    agentesFile = open("agentes.txt","r")
    for linea in agentesFile.readlines():
        if linea.find('#') != -1:
            totalAgentes +=1
        elif linea.find('nombre =') != -1:
            x = linea.split('=')
            y = x[1].split('\n')
            comunidadAgentes.append(y[0])
        elif linea.find('direccion =') != -1:
            x = linea.split('=')
            y = x[1].split('\n')
            ipAgentes.append(y[0])
    return totalAgentes
def supervicionAgentes(com,host):
    print("\t### Supervición del rendimiento, medición e informes ###")
    """Las mediciones del rendimiento deben ser adquiridas de forma periódica
    utilizando SNMP y deben ser almacenadas en RRDTOOL. El módulo monitorizará el
    uso de CPU, RAM y Disco duro de varios agentes. Los informes serán generados
    automáticamente; mostrará la información de inventario y las gráficas de los
    objetos monitorizados."""
    while True:
        CPUload1 = int(consultaSNMP(com, host, '1.3.6.1.2.1.25.3.3.1.2.196608'))
        CPUload2 = int(consultaSNMP(com, host, '1.3.6.1.2.1.25.3.3.1.2.196609'))
        CPUload3 = int(consultaSNMP(com,host, '1.3.6.1.2.1.25.3.3.1.2.196610'))
        CPUload4= int(consultaSNMP(com, host, '1.3.6.1.2.1.25.3.3.1.2.196611'))
        CPUload5 = int(consultaSNMP(com, host, '1.3.6.1.2.1.25.3.3.1.2.196612'))
        CPUload6 = int(consultaSNMP(com, host, '1.3.6.1.2.1.25.3.3.1.2.196613'))
        CPUload7 = int(consultaSNMP(com, host, '1.3.6.1.2.1.25.3.3.1.2.196614'))
        CPUload8 = int(consultaSNMP(com, host, '1.3.6.1.2.1.25.3.3.1.2.196615'))
        print(com)
        valor = "N:" + str(CPUload1)+":"+str(CPUload2)+":"+str(CPUload3)+":"+str(CPUload4)+":"+str(CPUload5)+":"+str(CPUload6)+":"+str(CPUload7)+":"+str(CPUload8)
        print(valor)

        if CPUload1 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload1"
            alertaComportamiento(CPUload1, nombreCPU)
            crearPDF(com, host, "nombreCPU")
        elif CPUload2 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload2"
            alertaComportamiento(CPUload2, nombreCPU)
            crearPDF(com, host, "nombreCPU")
        elif CPUload3 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload3"
            alertaComportamiento(CPUload3, nombreCPU)
            crearPDF(com, host, "nombreCPU")
        elif CPUload4 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload4"
            alertaComportamiento(CPUload4, nombreCPU)
            crearPDF(com, host, "nombreCPU")
        elif CPUload5 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload5"
            alertaComportamiento(CPUload5, nombreCPU)
            crearPDF(com, host, "nombreCPU")
        elif CPUload6 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload6"
            alertaComportamiento(CPUload6, nombreCPU)
            crearPDF(com, host, "nombreCPU")
        elif CPUload7 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload7"
            alertaComportamiento(CPUload7, nombreCPU)
            crearPDF(com,host,"nombreCPU")
        elif CPUload8 > CPU_UMBRAL[0]:
            nombreCPU = "CPUload8"
            alertaComportamiento(CPUload8, nombreCPU)
        ret = rrdtool.update(rrdpath + rrdname, valor)
        rrdtool.dump(rrdpath + rrdname, 'trend.xml')

        time.sleep(1)

def crearGraficaCPU(nombreCPU):

    ultima_lectura = int(rrdtool.last(rrdpath + rrdname))
    tiempo_final = ultima_lectura
    tiempo_inicial = tiempo_final - 1800  # Del ultimo valor buscame una hora atras

    # Esta funcion me permite extraer la informacion de RRD y guardarla en ret
    # con un print se puede imprimir el resultado

    ret = rrdtool.graph(pngpath + "trend"+str(nombreCPU)+".png",
                        "--start", str(tiempo_inicial),  # tiempo incial
                        "--end", str(tiempo_final),  # Tiempo final
                        "--vertical-label=Carga de CPU",
                        "--title=Uso de CPU",
                        "--vertical-label= Uso de CPU (%)",
                        '--lower-limit', '0',  # Limite Inferior
                        '--upper-limit', '100',  # Limite superior
                        "DEF:carga=" + rrdpath + rrdname + ":"+str(nombreCPU)+":AVERAGE",
                        "CDEF:umbralReady=carga,"+str(CPU_UMBRAL[0])+",LT,0,carga,IF",
                        "CDEF:umbralSet=carga," + str(CPU_UMBRAL[1]) + ",LT,0,carga,IF",
                        "CDEF:umbralGo=carga," + str(CPU_UMBRAL[2]) + ",LT,0,carga,IF",
                        "VDEF:cargaMAX=carga,MAXIMUM",
                        "VDEF:cargaMIN=carga,MINIMUM",
                        "VDEF:cargaSTDEV=carga,STDEV",
                        "VDEF:cargaLAST=carga,LAST",
                        "AREA:carga#00aAEFF:Carga del CPU",
                        # Definicion de areas de umbrales
                        "AREA:umbralReady#FBFF01:Carga mayor que " + str(CPU_UMBRAL[0]),
                        "AREA:umbralSet#FF8C00:Carga mayor que " + str(CPU_UMBRAL[1]),
                        "AREA:umbralGo#FF0D00:Carga mayor que " + str(CPU_UMBRAL[2]),
                        "HRULE:" + str(CPU_UMBRAL[0]) + "#00FF00:Umbral 1 - " + str(int(CPU_UMBRAL[0])) + "%",
                        "HRULE:" + str(CPU_UMBRAL[1]) + "#FFEC01:Umbral " + str(int(CPU_UMBRAL[0]) + 1) + " - " + str(CPU_UMBRAL[1]) + "%",
                        "HRULE:" + str(CPU_UMBRAL[2]) + "#FF9F00:Umbral " + str(int(CPU_UMBRAL[1]) + 1) + " - " + str(CPU_UMBRAL[2]) + "%",
                        "PRINT:cargaLAST:%6.2lf %S",
                        "GPRINT:cargaMIN:%6.2lf %SMIN",
                        "GPRINT:cargaSTDEV:%6.2lf %SSTDEV",
                        "GPRINT:cargaLAST:%6.2lf %SLAST")



def alertaComportamiento(carga_CPU,nombreCPU):
    CPU_FLAG = True
    crearGraficaCPU(nombreCPU)
    if CPU_FLAG:
        send_alert_attached("Ricardo Vargas Sagrero", nombreCPU)
        CPU_FLAG = False
    CPU_FLAG = False

# MAIN
com = []
host = []
totalAgentes = extraerAgentesTxt(com,host)
result = ""
cargaCPU = 0

while True:
    for i in range(totalAgentes):
        result = consultaSNMP(com[i],host[i],"1.3.6.1.2.1.1.1.0")
        if result.find("No SNMP response") == -1:
            print("Agente ",i+1,"=",result," Up")
            t1_agente = threading.Thread(name="Hilo_agente_1",
                                         target=supervicionAgentes,
                                         args=(com[i], host[i]))
            if not t1_agente.is_alive():
                t1_agente.start()

        else:
            print("Agente ",i+1,str(host[i]),"= Down")

    time.sleep(30)
