import rrdtool
import time
from path import *
ultima_lectura = int(rrdtool.last(rrdpath+rrdname))
tiempo_final = ultima_lectura
tiempo_inicial = tiempo_final - 1800 # Del ultimo valor buscame una hora atras

# Esta funcion me permite extraer la informacion de RRD y guardarla en ret
# con un print se puede imprimir el resultado

ret = rrdtool.graph(pngpath+"trend.png",
                     "--start", str(tiempo_inicial), # tiempo incial
                     "--end", str(tiempo_final), # Tiempo final
                     "--vertical-label=Carga CPU",
                     "--title=Uso de CPU",
                     "--color", "ARROW#009900",
                     '--vertical-label', "Uso de CPU (%)",
                     '--lower-limit', '0', # Limite Inferior
                     '--upper-limit', '100', # Limite superior
                     "DEF:carga="+rrdpath+rrdname+":CPUload:AVERAGE", #DEF nos ayuda a definir una coleccion de datos. ayuda a cargar en memoria toda
                     "AREA:carga#00FF00:Carga CPU",
                     "LINE1:30",
                     "AREA:5#ff000022:stack",
                     "VDEF:CPUlast=carga,LAST", # Tienen un input una coleccion, y como output un punto, ese output debe cumplir la conexion
                     "VDEF:CPUmin=carga,MINIMUM", # El valor minimo, todas esta funciones de RRD esta diseñada para analizar coleccion de datos
                     "VDEF:CPUavg=carga,AVERAGE",
                     "VDEF:CPUmax=carga,MAXIMUM",
                 #   "VDEF:CargaSTDEV=carga,STDEV",
                 #   "VDEF:CargaLast=carga,LAST,

                    "COMMENT:Now          Min             Avg             Max",
                     "GPRINT:CPUlast:%12.0lf%s", # GPRINT imprime en al grafica y PRINT EN la variable
                     "GPRINT:CPUmin:%10.0lf%s",
                     "GPRINT:CPUavg:%13.0lf%s",
                     "GPRINT:CPUmax:%13.0lf%s",
                     "VDEF:m=carga,LSLSLOPE", # VDEF necesita una variable que sea una coleccion salida tipo escalar
                     "VDEF:b=carga,LSLINT",
                     'CDEF:tendencia=carga,POP,m,COUNT,*,b,+', # CDEF tiene un input tipo coleccion y una salida tipo coleccion
                     "LINE2:tendencia#FFBB00" )

